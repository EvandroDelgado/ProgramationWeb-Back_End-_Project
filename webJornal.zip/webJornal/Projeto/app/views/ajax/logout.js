function myFunction() {
    localStorage.removeItem('user')
    localStorage.removeItem('idUser')
    window.location.replace("https://ea8-cfportela.c9users.io/paginaInicial")
}